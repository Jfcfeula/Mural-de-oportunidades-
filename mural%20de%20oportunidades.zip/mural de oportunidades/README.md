# Mural de Oportunidades

API REST para um mural de oportunidades acadêmicas e profissionais — estágios, cursos e eventos. Desenvolvida em Node.js com Express e SQLite.

## Tecnologias

- Node.js 22 ou superior (necessário para a versão atual do better-sqlite3)
- Express
- better-sqlite3
- CORS
- SQLite

## Estrutura

```text
Oportunidades_atualizado/
├── .gitignore
├── README.md
├── package.json
└── src/
    ├── server.js
    ├── database.js
    ├── seed.js
    ├── routes/
    │   └── oportunidades.js
    └── validacao/
        └── oportunidade.js
```

O banco `mural.db` é criado automaticamente na primeira execução e não é incluído nesta pasta.

## Instalação

```bash
npm install
```

## Execução

Desenvolvimento:

```bash
npm run dev
```

Produção:

```bash
npm start
```

Carga inicial de dados:

```bash
npm run seed
```

**Atenção:** o comando `npm run seed` apaga os registros existentes da tabela `oportunidades` antes de inserir os 60 registros de exemplo.

## Validação

O middleware `validarOportunidade` está em `src/validacao/oportunidade.js`.

Ele verifica título, tipo, instituição, modalidade, prazo, link, descrição e `criado_em`. Os campos `link` e `descricao` são opcionais. `criado_em` também pode ser omitido, pois o banco possui um valor padrão.

Para utilizar o middleware em uma rota de criação ou edição, importe-o no arquivo de rotas:

```javascript
const { validarOportunidade } = require('../validacao/oportunidade');
```

E adicione-o à rota que recebe o corpo da oportunidade, por exemplo:

```javascript
router.post('/', validarOportunidade, (req, res) => {
    // lógica de criação
});
```
