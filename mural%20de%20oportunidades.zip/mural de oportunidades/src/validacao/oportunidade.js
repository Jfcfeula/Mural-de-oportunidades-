const TIPOS = ['estagio', 'curso', 'evento'];
const MODALIDADES = ['presencial', 'online', 'hibrido'];

// Verifica o formato AAAA-MM-DD e se a data realmente existe.
function dataValida(texto) {
    if (typeof texto !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(texto)) {
        return false;
    }

    const [ano, mes, dia] = texto.split('-').map(Number);
    const data = new Date(0);
    data.setHours(0, 0, 0, 0);
    data.setFullYear(ano, mes - 1, dia);

    return (
        data.getFullYear() === ano &&
        data.getMonth() === mes - 1 &&
        data.getDate() === dia
    );
}

function textoPreenchido(valor) {
    return typeof valor === 'string' && valor.trim() !== '';
}

// Middleware: valida o corpo da requisição antes de chegar à rota.
function validarOportunidade(req, res, next) {
    const {
        titulo,
        tipo,
        instituicao,
        modalidade,
        prazo,
        link,
        descricao,
        criado_em
    } = req.body ?? {};

    const erros = [];

    if (!textoPreenchido(titulo) || titulo.trim().length < 4) {
        erros.push('O título é obrigatório e deve ter ao menos 4 caracteres');
    }

    if (!TIPOS.includes(tipo)) {
        erros.push(`O tipo deve ser um destes: ${TIPOS.join(', ')}`);
    }

    if (!textoPreenchido(instituicao)) {
        erros.push('A instituição é obrigatória');
    }

    if (!MODALIDADES.includes(modalidade)) {
        erros.push(`A modalidade deve ser uma destas: ${MODALIDADES.join(', ')}`);
    }

    if (!dataValida(prazo)) {
        erros.push('O prazo deve ser uma data válida no formato AAAA-MM-DD');
    }

    // Link é opcional; quando informado, deve ser uma URL HTTP ou HTTPS válida.
    if (link !== undefined && link !== null && link !== '') {
        if (typeof link !== 'string') {
            erros.push('O link deve ser um texto contendo uma URL válida');
        } else {
            try {
                const url = new URL(link);

                if (!['http:', 'https:'].includes(url.protocol) || !url.hostname) {
                    erros.push('O link deve utilizar uma URL HTTP ou HTTPS válida');
                }
            } catch {
                erros.push('O link informado não é uma URL válida');
            }
        }
    }

    // Descrição é opcional, mas precisa ser texto quando enviada.
    if (
        descricao !== undefined &&
        descricao !== null &&
        typeof descricao !== 'string'
    ) {
        erros.push('A descrição deve ser um texto');
    }

    // criado_em é gerado pelo banco por padrão; se enviado, deve ser uma data/hora válida.
    if (criado_em !== undefined && criado_em !== null && criado_em !== '') {
        if (
            typeof criado_em !== 'string' ||
            !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(criado_em) ||
            !dataValida(criado_em.slice(0, 10)) ||
            !horaValida(criado_em.slice(11))
        ) {
            erros.push('A data de criação deve ser válida no formato AAAA-MM-DD HH:MM:SS');
        }
    }

    if (erros.length > 0) {
        return res.status(400).json({ erros });
    }

    next();
}

function horaValida(texto) {
    if (!/^\d{2}:\d{2}:\d{2}$/.test(texto)) return false;

    const [hora, minuto, segundo] = texto.split(':').map(Number);

    return hora <= 23 && minuto <= 59 && segundo <= 59;
}

module.exports = {
    validarOportunidade,
    dataValida,
    textoPreenchido
};
